'use strict';

/*
    This file can be used as entry point for webpack!
 */
